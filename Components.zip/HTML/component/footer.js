function footer(){
    return `
    <div class="lst" > 
    <img class="logo2" src="https://static.frontendmasters.com/assets/fm/js/static/frontendmasters.e1e10b58c1.svg" alt="">    
    <ul>
       <a href=""><li>Courses</li></a>
       <a href=""><li>Learn</li></a>
       <a href=""><li>Teachers</li></a>
       <a href=""><li>Guides</li></a>
       <a href=""><li>Pricing</li></a>
       <a href=""><li>Login</li></a>
       <a href=""><li>Join Now</li></a>
       <a href=""><li>FAQ</li></a>
    
    </ul>
    
    </div>
    
    <div id="appDiv">
    <img id="apple" src="../Images/download-on-the-app-store.png" alt="">    
    <img id="google" src="../Images/en_badge_web_generic.png" alt="">
    </div>
    
    <div class="lstlogo" >
        <img class="lg" src="../images/tweet.png" alt="">
        <img class="lg" src="../images/linkedin.png" alt="">
        <img class="lg" src="../images/fb.png" alt="">
        <img class="lg" src="../images/instagram.png" alt="">
        <p style="color: rgb(143, 134, 134);font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;padding-left: 62%;margin-top: 10px; " >Email : <a style="color: orangered;" href="mailto:support@frontendmasters.com">support@frontendmasters.com</a></p>
    
    
    </div>
    
    <div id="bottomDiv"> <p>Frontend Masters is proudly made in Minneapolis, MN</p> <p>© 2021 Frontend Masters · <a href="https://static.frontendmasters.com/assets/legal/MasterServicesAgreement.pdf">Terms of Service</a> · <a href="https://static.frontendmasters.com/assets/legal/PrivacyPolicy.pdf">Privacy Policy</a> </p></div>
    
    
    
    `
    }
    export default footer;