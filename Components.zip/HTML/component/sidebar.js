function sidebar(){
    return `
    <div class="green"><a href="account.html">Account</a></div>
    <div class="green"><a href="Subscription.html">Subscription</a></div>
    <div class="green"><a href="Payment.html">Payment</a></div>
    <div class="green"><a href="Invoices.html">Invoices</a></div>
    <div class="green"><a href="Workshops.html">Workshops</a></div>
`
}
 
export default sidebar;


