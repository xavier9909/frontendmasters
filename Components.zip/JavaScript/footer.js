function footer() {
 return `<div class="footer" >
<div class="lst" > 
<img class="logo2" src="https://static.frontendmasters.com/assets/fm/js/static/frontendmasters.e1e10b58c1.svg" alt="">    
<ul>
   <a href=""><li>Courses</li></a>
   <a href=""><li>Learn</li></a>
   <a href=""><li>Teachers</li></a>
   <a href=""><li>Guides</li></a>
   <a href=""><li>Pricing</li></a>
   <a href=""><li>Login</li></a>
   <a href=""><li>Join Now</li></a>
   <a href=""><li>FAQ</li></a>

</ul>

</div>
<img class="download"src="./img/download.png" alt="">
<div class="lstlogo" >
    <img class="lg" src="./img/tweet.png" alt="">
    <img class="lg" src="./img/linkedin.png" alt="">
    <img class="lg" src="./img/fb.png" alt="">
    <img class="lg" src="./img/instagram.png" alt="">
    <p style="color: rgb(143, 134, 134);font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;padding-left: 56.5%;margin-top: 10px; " >Email : <a style="color: orangered;" href="">support@frontendmasters.com</a>  </p>


</div>

<img class="lstl" src="./img/lstl.png" alt="">

</div>`

   
}

export {footer}